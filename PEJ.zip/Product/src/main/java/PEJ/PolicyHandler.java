package PEJ;

import PEJ.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PolicyHandler{

    @Autowired
    ProductRepository productRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverPurchased_ChangeInventory(@Payload Purchased purchased){

        if(purchased.isMe()){

            Optional<Product> productOptional = productRepository.findById(Long.valueOf("" + purchased.getPrdId()));
            Product product = productOptional.get();
            
            // 품절여부체크
            product.setPrdQty(product.getPrdQty() - purchased.getPurchaseQty());

            if( product.getPrdQty() < 0 ){
                System.out.println("productOutOfStock 이벤트 발생");
                OutOfStock outOfStock = new OutOfStock();
                outOfStock.setPrdId(purchased.getPrdId());
                outOfStock.setPurchaseId(purchased.getPurchaseId());
                outOfStock.publish();
                System.out.println("##### listener ChangeInventory : 구매 >> 실패");

            }else{
                // 품절이 아닌 경우만 재고수정
                productRepository.save(product);
                System.out.println("##### listener ChangeInventory : 구매 >> 성공");
            }

            System.out.println("##### listener ChangeInventory : " + purchased.toJson());

        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverCancelled_ChangeInventory(@Payload Cancelled cancelled){

        if(cancelled.isMe()){
            Optional<Product> productOptional = productRepository.findById(Long.valueOf("" + cancelled.getPrdId()));
            Product product = productOptional.get();

            // 취소수량 복구
            product.setPrdQty(product.getPrdQty() + cancelled.getPurchaseQty());
            productRepository.save(product);
            System.out.println("##### listener ChangeInventory : 구매 취소 >> 성공");

            System.out.println("##### listener ChangeInventory : " + cancelled.toJson());
        }
    }
    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverShipped_ReceiveProduct(@Payload Shipped shipped){

        if(shipped.isMe()){
            Optional<Product> productOptional = productRepository.findById(Long.valueOf("" + shipped.getPrdId()));
            Product product = null;

            try{
                product = productOptional.get();    // 기존상품 조회
            }
            catch (java.util.NoSuchElementException ex){
                product = new Product();    // NoSuchElementException : 최초입고인 경우는 생성
            }
            finally {

                product.setPrdQty(product.getPrdQty() + shipped.getPrdQty()); // 기존재고 + 입고수량
                product.setPrdNm(shipped.getPrdNm());
                product.setPrdPrice(shipped.getPrdPrice());

                productRepository.save(product);
                System.out.println("##### listener ReceiveProduct : " + shipped.toJson());
            }

        }
    }

}
