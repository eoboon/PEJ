package PEJ;

import PEJ.config.kafka.KafkaProcessor;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.stream.annotation.StreamListener;
import org.springframework.messaging.handler.annotation.Payload;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class PolicyHandler{

    @Autowired
    PurchaseRepository purchaseRepository;

    @StreamListener(KafkaProcessor.INPUT)
    public void onStringEventListener(@Payload String eventString){

    }

    @StreamListener(KafkaProcessor.INPUT)
    public void wheneverOutOfStock_Cancel(@Payload OutOfStock outOfStock){

        if(outOfStock.isMe()){
            Optional<Purchase> purchaseOptional  = purchaseRepository.findById(Long.valueOf("" + outOfStock.getPurchaseId()));
            Purchase purchase = purchaseOptional.get();

            // 구매취소 처리
            purchase.setPurchaseStatus("CANCELLED(Out of stock)");
            purchaseRepository.save(purchase);
            System.out.println("##### listener Cancel : 구매 취소(Out of stock) >> 성공");

            System.out.println("##### listener Cancel : " + outOfStock.toJson());
        }
    }

}
